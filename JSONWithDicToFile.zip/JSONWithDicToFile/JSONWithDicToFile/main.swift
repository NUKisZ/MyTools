//
//  main.swift
//  JSONWithDicToFile
//
//  Created by 张坤 on 2018/2/5.
//  Copyright © 2018年 张坤. All rights reserved.
//

import Foundation
let userKey = "kSingLove"
let json="""
{
"title": "汗流浃背真是爽翻了",
"imgurl": "http://www.singlove.com/video/thumbnail/54593.jpeg?t=1497939917&v=2",
"videourl": "http://cdn5.looklook.space/videos/0/54593/54593.240p.m3u8?v=1.1",
"duration": "28:42",
"id": "817c5627452c505723c0d0f494ab55aa",
"heartnum": "33800",
"updated": "2016-11-12",
"addtime": "2018-01-23 22:30:34+08:00",
"tag": "大马"
}
"""
func getDictionaryFromJSONString(jsonString:String) ->NSDictionary{

    let jsonData:Data = jsonString.data(using: .utf8)!

    let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
    if dict != nil {
        return dict as! NSDictionary
    }
    return NSDictionary()


}
let dic = getDictionaryFromJSONString(jsonString: json)
var ReformeKeys = ""
ReformeKeys = ReformeKeys + """
//
//  main.swift
//  JSONWithDicToFile
//
//  Created by 张坤 on 2018/2/5.
//  Copyright © 2018年 张坤. All rights reserved.
//
\n\n\n\n\n\n
"""
for (key,_) in dic{
    var keyS = key as! String
    keyS = userKey+keyS.capitalized
    //extern NSString * const kHomeChannelID;
    keyS = "extern NSString * const " + keyS + ";\n"
    ReformeKeys = ReformeKeys + keyS
}
ReformeKeys = ReformeKeys + "\n\n\n\n\n\n"

for(key,_)in dic{
    var keyS = key as! String
    keyS = userKey+keyS.capitalized
    keyS = "NSString * const " + keyS + " = @\"" + keyS + "\";\n"
    ReformeKeys = ReformeKeys + keyS
}
ReformeKeys = ReformeKeys + "\n\n\n\n\n\n"

ReformeKeys = ReformeKeys + "NSDictionary *dict=@{\n"
for(key,_)in dic{
    var keyS = key as! String
    keyS = userKey+keyS.capitalized
    keyS = keyS + ":dic[@\"" + (key as! String) + "\"],\n"
    ReformeKeys = ReformeKeys + keyS
}
ReformeKeys = String(ReformeKeys.dropLast(2))
ReformeKeys = ReformeKeys + "\n"
ReformeKeys = ReformeKeys + "};"






ReformeKeys = ReformeKeys + "\n\n\n\n\n\n"


var okString = ReformeKeys as NSString
do {
    try okString.write(toFile: "/Users/zhangkun/Downloads/dic.h", atomically: true, encoding: String.Encoding.utf8.rawValue)
    print("完成")
}catch{
    print(error)
}
